<?php 

require_once './database.php';
$connect = mysqli_connect($hostname, $username, $password, $dbname);
				
    if(isset($_POST["submit"]))
        {
            $username = $_POST["username"];
            $password = $_POST["password"];
            $id_role = $_POST["id_role"];
            if ($username ==""||$password ==""||$id_role == "") 
            {
                echo "Please fill the blank!";
            }
            else{
                $sql = "select * from tblaccount where username= '$username'";
                $query = mysqli_query($connect, $sql);
                if(mysqli_num_rows($query) > 0)
                {
                    echo "Account already available!";
                }
                else{
                    $sql = "INSERT INTO tblaccount VALUES (null, '$username','$password','$id_role')";
                    mysqli_query($connect,$sql);
                }
                if ($sql == true){
                    header("location: pages/1listAccount.php");
                }

        }
    }
            
?>

