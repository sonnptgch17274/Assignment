<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css" />
<title>SlickGray | florida web design</title>
</head>

<body>
<div id="container">
		<div id="header">
        	
            <a href="http://localhost/ASM/asm/pages/adminstrator.php"><h1>Adminstrator<span class="off">Joker</span></h1></a>
            <h2>University of Greenwich</h2>
        </div>   