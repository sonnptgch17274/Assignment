<div id="leftmenu">



        <div id="leftmenu_main">    
        
        <h3>Management</h3>
                
        <ul>
            <li><a href="http://localhost/ASM/asm/pages/1listAccount.php">Account</a></li>
            <li><a href="http://localhost/ASM/asm/pages/2listTrainer.php">Trainer</a></li>
            <li><a href="http://localhost/ASM/asm/pages/3listTrainee.php">Trainee</a></li>
            <li><a href="http://localhost/ASM/asm/pages/listCategory.php">Category</a></li>
        </ul>
</div>
        
        
      <div id="leftmenu_bottom"></div>
</div>