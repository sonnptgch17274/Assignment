<?php 

	require("./database.php");
	$connect = mysqli_connect($hostname, $username, $password, $dbname);

	if(isset($_GET["id"]))
	{	
		$id = $_GET["id"];
		$sql = "DELETE FROM tbltrainee WHERE IDTrainee=" . $id;
		echo $sql;
		mysqli_query($connect,$sql);	
		if ($sql == true){
			header("location: pages/3listTrainee.php");
		}				
	}

?>