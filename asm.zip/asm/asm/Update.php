<?php 
	require("./database.php");
	$connect = mysqli_connect($hostname, $username, $password, $dbname);

    if(isset($_GET["id"]))
        {   
            $id = $_GET(["id"]);
            $username = $_POST["username"];
            $password = $_POST["password"];
            $id_role = $_POST["id_role"];

            if ($id ==""||$username ==""||$password ==""||$id_role == "") 
                {
                    echo "Please fill the blank!";
                }
            else
                {
                    $sql = "select * from tblaccount where Username= '$username'";
                    $sql = "UPDATE tblaccount SET accountid='$id' Username='$username',Password='$password',ID_Role='$id_role' WHERE accountid=" . $id;
                    mysqli_query($connect,$sql);
                    echo $sql;
                    
                }
        }
?>