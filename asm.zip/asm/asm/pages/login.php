<?php 
if(isset($_POST['username']) && ($_POST['password'])){
    if(isset($_POST['remember'])){
        setcookie("logged", $_POST['username'], time() + (30*86400), "/" );
    }
    // else{
    //     session_start();
    //     $_SESSION = ['logged'] = $_POST['username'];
    // }
}else{
    $error = "You have to enter username and password";
}
echo $_SESSION['logged'];

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../style.css" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<title>SlickGray | florida web design</title>
</head>

<body>
<div id="container">
        <?php require_once("../blocks/header.php"); ?>
        
        <?php require_once("../blocks/menu.php"); ?>

        <?php require_once("../blocks/leftmenu.php"); ?>
        
        
		<div id="content">
        
        
        <div id="content_main">

        <!-- require content here -->
  <div class="imgcontainer">

  </div>

  <div class="container">
    
  <div style="padding-left: 400px;">Log in
    <form action="adminstrator.php" method="POST">
        <br>
    Username: <input type="text" name="username" placeholder="Username"><br>
    Password: <input type="Password" name="password" placeholder="Password"><br>
    <input type="checkbox" name="remember" value=1>Remember password
    <input style="margin-left: 50px;" type="Submit" value="Login">
    <input type="Reset" value="Reset">
    </form>
    <div>You have an account?<a href="">Sign up</a></div></div>
    <?php 
        echo (isset($error)) ? $error : ""; 
    ?>
<p>&nbsp;</p>
        </div>

<?php require_once("../blocks/footer.php"); ?>