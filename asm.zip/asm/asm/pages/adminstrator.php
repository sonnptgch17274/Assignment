<?php
sessison_start();
if(isset($_SESSION['accountid']) && $_SESSION['id_role'] == 2)
{
 // tại đây thực thi các hoạt động khi đăng nhập thành công.
}
else
{
 header("location: login.php");
 exit();
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="../style.css" />
<title>SlickGray | florida web design</title>
</head>

<body>
<div id="container">
        <?php require_once("../blocks/header.php"); ?>
        
        <?php require_once("../blocks/menu.php"); ?>

        <?php require_once("../blocks/leftmenu.php"); ?>
        
        
		<div id="content">
        
        

        <div id="content_main">

        <!-- require content here -->
        


<p>&nbsp;</p>
        </div>

<?php require_once("../blocks/footer.php"); ?>