<?php 

	require("./database.php");
	$connect = mysqli_connect($hostname, $username, $password, $dbname);

	if(isset($_GET["id"]))
	{	
		$id = $_GET["id"];
		$sql = "DELETE FROM tblcategory WHERE IDCat=" . $id;
		echo $sql;
		mysqli_query($connect,$sql);	
		if ($sql == true){
			header("location: pages/listCategory.php");
		}				
	}

?>