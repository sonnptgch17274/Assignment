<?php 

require_once './database.php';
$connect = mysqli_connect($hostname, $username, $password, $dbname);
				
    if(isset($_POST["submit1"]))
        {
            $name = $_POST["name"];
            $email = $_POST["email"];
            $phone = $_POST["phone"];
            $address = $_POST["address"];
            if ($name ==""||$email ==""||$phone == ""||$address == "") 
            {
                echo "Please fill the blank!";
            }

            else{
                $sql = "INSERT INTO tbltrainer VALUES (null, '$name','$email','$phone', '$address')";
                mysqli_query($connect,$sql);
                echo $sql;
            }
            if ($sql == true){
                header("location: pages/2listTrainer.php");
            }

        }
    
            
?>

